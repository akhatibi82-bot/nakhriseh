Nakhriseh Shop UI
Version: 1.3.7
Author: Aryana System

CHANGES IN 1.3.7
- Fixed featured-image visibility when a product has no gallery thumbnails.
- Ensured the selected variation image is shown by returning the gallery to its first slide after variation selection or reset.

PURPOSE
A redesigned WooCommerce product-detail and shop-archive presentation for Nakhriseh. It uses its own namespaced CSS and JavaScript and does not replace WooCommerce template files.

INSTALL
1. Extract the ZIP.
2. Upload the folder `nakhriseh-shop-ui` to:
   wp-content/plugins/
3. In WordPress Admin > Plugins, activate “Nakhriseh Shop UI”.
4. Clear any page/cache plugin cache and hard-refresh the product page.

CHANGES IN 1.2.1
- Aligned product detail layout with the approved reference: right-side vertical gallery thumbnails, rounded product panel, coral price accent, rounded purchase action and three-column trust strip.
- Added visual variation chips that proxy WooCommerce native variation selects; native variation/cart logic remains authoritative.
- Added accessible quantity increment/decrement controls while retaining WooCommerce quantity input.
- Separated upsells and related products into distinct grid rows to prevent overlap.
- Removed the extra editorial note that was not part of the approved reference.

CHANGES IN 1.2.0
- Renamed all plugin-owned CSS classes and CSS custom properties from the old `nshu-` prefix to the unique `nakh-riseh-ui-` prefix across PHP, CSS and JavaScript.
- Kept WooCommerce core classes unchanged because WooCommerce relies on them.
- Preserved the existing plugin folder, file names, enqueue handles and WooCommerce behavior.

DESIGN CHANGES IN 1.1.0
- New editorial two-column product detail layout with a distinct gallery and purchase-summary panel.
- New scoped visual system: paper background, forest-green typography/actions, clay accents, thin borders and square editorial components.
- Reworked product title, price/discount hierarchy, variation selectors, quantity and add-to-cart controls.
- New purchase-information strip and editorial note.
- New product description/specification/review tab styling.
- New responsive related-product and shop-category product cards.
- Dedicated responsive archive grid, sorting and pagination styles.
- CSS and JS load only on WooCommerce product and shop/category/tag pages.

COMPATIBILITY / SAFETY
- Does not edit StoreVilla, theme files, WooCommerce templates, or existing product data.
- Keeps WooCommerce's native product gallery, variation selection, stock status, cart form, price output, tabs, reviews, related products, links and archive queries.
- CSS is scoped to uniquely named body classes added by this plugin. Plugin-owned classes use the `nakh-riseh-ui-` prefix; WooCommerce core classes remain unchanged.
- Requires WooCommerce. If WooCommerce is inactive, the plugin does not initialize its UI hooks.

IMPORTANT
This package was syntax-checked where PHP is available, but it has not been installed on the user's local WordPress site or tested against the exact StoreVilla/WooCommerce versions and active plugins. Verify variable products, gallery zoom/lightbox, reviews, cart and mobile layout on a staging copy before production use.

= 1.2.3 =
* Fixed product gallery behavior by preserving WooCommerce FlexSlider slide visibility and viewport height calculation.
* Strengthened product-title typography and color overrides against StoreVilla theme styles.


= 1.2.4 =
* Added WooCommerce's native single-product and variation scripts as explicit dependencies so the gallery slider and variation behavior initialize reliably.
* Removed generated color/variation chips that duplicated the existing variation UI and used a hard-coded color map. Existing theme/plugin swatches and configured attribute colors are now preserved.


= 1.2.5 =
* Preserved WooCommerce FlexSlider's measured slide widths and native thumbnail click handling.
* Added a scrollable vertical thumbnail rail with arrow controls and mouse-drag scrolling for products with many images.
* Rounded existing configured color swatches without hardcoding or replacing their colors.
* Centered add-to-cart button icon and text as a single inline-flex group.
* Standardized the sale badge to one red, softly rounded label.
* Applied requested current-price and previous-sale-price font/color hierarchy.


= 1.2.6 =
* Reduced the previous sale price to 82% of the current price size while keeping it bold and red.
* Hid WooCommerce's native sale badge across the single-product page while retaining the plugin badge.
* Added a defensive FlexSlider thumbnail-click fallback and increased the mouse-drag threshold to avoid swallowing ordinary clicks.
* Preserved the vertical thumbnail rail, arrows, and drag-to-scroll behavior.


= 1.2.8 =
* Changed the product gallery to show the selected slide directly instead of relying on FlexSlider's translate animation, addressing the reported case where the active thumbnail changed but the main image did not.
* Kept the original WooCommerce image/link markup, variation form, quantity input, and add-to-cart behavior.
* Reapplies gallery display rules after variation events.
* Requires live testing on the site's active theme/plugins; zoom/lightbox and variation image replacement should be checked after installation.


= 1.3.1 =
* Display the second variation attribute (size) as single-select buttons with hover and selected states.
* Keep WooCommerce native variation selection and stock/availability matching.

= 1.3.0 =
* Added a dedicated body class and responsive cart-page styling scoped to the WooCommerce cart page.
* Preserved WooCommerce's native cart form, quantity updates, coupon handling, totals, shipping calculation, and checkout link.
* Product and archive styling selectors were not changed.

= 1.3.9 =
* Main product image now has a square frame with a subtle border.
* Gallery/variation thumbnails remain in a separate side rail.

= 1.3.10 =
* Hide the empty thumbnail rail when a product has only its featured image and no gallery or variation images.
