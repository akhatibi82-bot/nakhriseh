(function ($) {
    'use strict';

    $(function () {
        var $productPage = $('body.nakh-riseh-ui-product-page');
        if (!$productPage.length) return;

        var $gallery = $productPage.find('.woocommerce-product-gallery');

        function setupGallery($currentGallery) {
            var $thumbs = $currentGallery.find('.flex-control-thumbs').first();

            // The featured image must remain visible even when the product has no gallery.
            // Thumbnails are optional; the main WooCommerce image is not.
            var $slides = $currentGallery.find('.woocommerce-product-gallery__wrapper > .woocommerce-product-gallery__image');
            if (!$slides.length) return;

            function showSlide(index) {
                index = parseInt(index, 10);
                if (!isFinite(index) || index < 0 || index >= $slides.length) return;

                var $wrapper = $currentGallery.find('.woocommerce-product-gallery__wrapper').first();
                var $viewport = $currentGallery.find('.flex-viewport').first();
                $wrapper.css({ width: '100%', transform: 'none', transition: 'none' });
                $slides.each(function (i) {
                    $(this).css({
                        display: i === index ? 'block' : 'none',
                        width: '100%',
                        float: 'none',
                        marginRight: '0',
                        position: 'relative',
                        left: 'auto',
                        right: 'auto'
                    }).toggleClass('nakh-riseh-ui-gallery-active', i === index);
                });
                if ($viewport.length) $viewport.css({ height: 'auto', overflow: 'hidden' });
                $thumbs.find('img').removeClass('flex-active').attr('aria-pressed', 'false');
                $thumbs.find('li').eq(index).find('img').first().addClass('flex-active').attr('aria-pressed', 'true');
                $currentGallery.data('nakhRisehActiveSlide', index);
            }

            // A product with only its featured image has no thumbnail rail.
            // Still initialize its first (and only) slide so the CSS visibility rules
            // cannot hide the image.
            if (!$thumbs.length) {
                showSlide(0);
                return;
            }

            $thumbs.find('img').attr({ tabindex: '0', role: 'button', 'aria-pressed': 'false' });
            var initialIndex = $thumbs.find('img.flex-active').closest('li').index();
            if (initialIndex < 0) initialIndex = $currentGallery.data('nakhRisehActiveSlide') || 0;
            showSlide(initialIndex);
            $thumbs.off('keydown.nakhRisehGallery').on('keydown.nakhRisehGallery', 'img', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    $(this).trigger('click');
                }
            });

            if ($currentGallery.data('nakhRisehThumbRailReady')) return;
            $currentGallery.data('nakhRisehThumbRailReady', true);

            var $previous = $('<button type="button" class="nakh-riseh-ui-gallery-arrow nakh-riseh-ui-gallery-arrow--previous" aria-label="تصاویر قبلی" title="تصاویر قبلی">‹</button>');
            var $next = $('<button type="button" class="nakh-riseh-ui-gallery-arrow nakh-riseh-ui-gallery-arrow--next" aria-label="تصاویر بعدی" title="تصاویر بعدی">›</button>');
            $currentGallery.append($previous, $next);

            function scrollThumbs(direction) {
                var item = $thumbs.find('li').first();
                var step = item.length ? (item.outerHeight(true) || 72) * 2 : 144;
                $thumbs.stop(true).animate({ scrollTop: $thumbs.scrollTop() + (direction * step) }, 180);
            }
            $previous.on('click', function () { scrollThumbs(-1); });
            $next.on('click', function () { scrollThumbs(1); });

            var dragging = false;
            var moved = false;
            var startY = 0;
            var startScroll = 0;
            $thumbs.on('mousedown.nakhRisehDrag', function (event) {
                if (event.button !== 0) return;
                dragging = true;
                moved = false;
                startY = event.pageY;
                startScroll = this.scrollTop;
                $thumbs.addClass('nakh-riseh-ui-thumbs-dragging');
            });
            $(document).on('mousemove.nakhRisehDrag', function (event) {
                if (!dragging) return;
                var delta = event.pageY - startY;
                if (Math.abs(delta) > 10) moved = true;
                if (moved) $thumbs[0].scrollTop = startScroll - delta;
            });
            $(document).on('mouseup.nakhRisehDrag', function () {
                if (!dragging) return;
                dragging = false;
                $thumbs.removeClass('nakh-riseh-ui-thumbs-dragging');
                if (moved) {
                    $thumbs.data('nakhRisehSuppressClick', true);
                    window.setTimeout(function () { $thumbs.removeData('nakhRisehSuppressClick'); }, 80);
                }
            });
            // If a small mouse movement is interpreted as a drag, do not swallow
            // the thumbnail click. Only suppress the click after a real drag gesture.
            $thumbs.off('click.nakhRisehDrag').on('click.nakhRisehDrag', 'img', function (event) {
                if ($thumbs.data('nakhRisehSuppressClick')) {
                    event.preventDefault();
                    event.stopImmediatePropagation();
                    return;
                }

                // Bypass FlexSlider's transform-based movement (the broken part) and
                // directly show the requested gallery item. Keep the original image/link
                // intact so WooCommerce zoom/lightbox and variation image updates survive.
                event.preventDefault();
                event.stopImmediatePropagation();
                var index = $(this).closest('li').index();
                showSlide(index);
            });

            function updateArrows() {
                var node = $thumbs[0];
                var hasOverflow = node.scrollHeight > node.clientHeight + 2;
                $previous.add($next).toggleClass('is-visible', hasOverflow);
                $previous.prop('disabled', node.scrollTop <= 1);
                $next.prop('disabled', node.scrollTop + node.clientHeight >= node.scrollHeight - 1);
            }
            $thumbs.on('scroll.nakhRisehRail', updateArrows);
            $(window).on('resize.nakhRisehRail', updateArrows);
            window.setTimeout(updateArrows, 250);
        }

        $gallery.each(function () { setupGallery($(this)); });

        // When the product has no gallery images, use variation images as the thumbnail rail.
        // Clicking a variation thumbnail selects its attributes; WooCommerce remains responsible
        // for changing the main product image and price.
        function setupVariationImageRail($currentGallery) {
            var $nativeThumbs = $currentGallery.find('.flex-control-thumbs').first();
            var $form = $productPage.find('form.variations_form').first();
            if ($nativeThumbs.find('li').length) {
                $currentGallery.removeClass('nakh-riseh-ui-no-thumbnails');
                return;
            }
            if (!$form.length) {
                $currentGallery.addClass('nakh-riseh-ui-no-thumbnails');
                return;
            }

            var variations = $form.data('product_variations');
            if (!Array.isArray(variations)) {
                var raw = $form.attr('data-product_variations');
                if (raw && raw !== 'false') {
                    try { variations = JSON.parse(raw); } catch (e) { variations = []; }
                }
            }
            if (!Array.isArray(variations)) variations = [];

            var seen = {};
            var imageVariations = [];
            variations.forEach(function (variation) {
                if (!variation || !variation.image) return;
                var image = variation.image;
                var thumb = image.gallery_thumbnail_src || image.thumb_src || image.src;
                var full = image.full_src || image.src;
                if (!thumb || !full) return;
                var key = String(full);
                if (seen[key]) return;
                seen[key] = true;
                imageVariations.push({ variation: variation, thumb: thumb, full: full, alt: image.alt || '' });
            });

            if (!imageVariations.length) {
                $currentGallery.addClass('nakh-riseh-ui-no-thumbnails');
                return;
            }

            $currentGallery.removeClass('nakh-riseh-ui-no-thumbnails');
            var $rail = $('<ol class="flex-control-thumbs nakh-riseh-ui-variation-thumbs" aria-label="تصاویر رنگ‌بندی محصول"></ol>');
            imageVariations.forEach(function (item, index) {
                var $img = $('<img>').attr({ src: item.thumb, alt: item.alt || 'تصویر متغیر محصول', tabindex: '0', role: 'button', 'aria-pressed': index === 0 ? 'true' : 'false' });
                if (index === 0) $img.addClass('flex-active');
                $('<li></li>').append($img).appendTo($rail);
            });
            $currentGallery.append($rail);

            function selectVariation(item, $img) {
                if (!item || !item.variation || !item.variation.attributes) return;
                Object.keys(item.variation.attributes).forEach(function (attributeName) {
                    var value = item.variation.attributes[attributeName];
                    var $select = $form.find('select[name="' + attributeName.replace(/([\\[\\]])/g, '\\$1') + '"]').first();
                    if (!$select.length) {
                        $select = $form.find('select').filter(function () {
                            return this.name === attributeName;
                        }).first();
                    }
                    if ($select.length && $select.val() !== value) $select.val(value).trigger('change');
                });
                $rail.find('img').removeClass('flex-active').attr('aria-pressed', 'false');
                $img.addClass('flex-active').attr('aria-pressed', 'true');
            }

            $rail.on('click', 'img', function (event) {
                event.preventDefault();
                var index = $(this).closest('li').index();
                selectVariation(imageVariations[index], $(this));
            }).on('keydown', 'img', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    $(this).trigger('click');
                }
            });

            $form.on('found_variation.nakhRisehVariationRail', function (event, variation) {
                var target = variation && variation.image ? (variation.image.full_src || variation.image.src) : '';
                if (!target) return;
                $rail.find('img').each(function (index) {
                    var active = imageVariations[index].full === target;
                    $(this).toggleClass('flex-active', active).attr('aria-pressed', active ? 'true' : 'false');
                });
            }).on('reset_data.nakhRisehVariationRail', function () {
                $rail.find('img').removeClass('flex-active').attr('aria-pressed', 'false');
            });
        }

        $gallery.each(function () { setupVariationImageRail($(this)); });
        $productPage.on('woocommerce_gallery_init.nakhRisehVariationRail', '.woocommerce-product-gallery', function () {
            setupVariationImageRail($(this));
        });
        // WooCommerce may rebuild the gallery after variation changes; re-apply only our rail controls.
        $productPage.on('woocommerce_gallery_init.nakhRiseh', '.woocommerce-product-gallery', function () {
            setupGallery($(this));
        });
        $productPage.on('found_variation.nakhRiseh reset_data.nakhRiseh', 'form.variations_form', function () {
            // WooCommerce changes the first gallery image to the selected variation image.
            // Always reveal that first slide after the variation image update; retaining a
            // previously selected gallery slide would otherwise conceal the new image.
            window.setTimeout(function () {
                $productPage.find('.woocommerce-product-gallery').each(function () {
                    var $current = $(this);
                    var $slides = $current.find('.woocommerce-product-gallery__wrapper > .woocommerce-product-gallery__image');
                    if (!$slides.length) return;

                    var $wrapper = $current.find('.woocommerce-product-gallery__wrapper').first();
                    var $thumbs = $current.find('.flex-control-thumbs').first();

                    $wrapper.css({ width: '100%', transform: 'none', transition: 'none' });
                    $slides.each(function (i) {
                        $(this).css({
                            display: i === 0 ? 'block' : 'none',
                            width: '100%',
                            float: 'none',
                            marginRight: '0',
                            position: 'relative',
                            left: 'auto',
                            right: 'auto'
                        }).toggleClass('nakh-riseh-ui-gallery-active', i === 0);
                    });

                    $current.find('.flex-viewport').css({ height: 'auto', overflow: 'hidden' });
                    $thumbs.find('img').removeClass('flex-active').attr('aria-pressed', 'false');
                    $thumbs.find('li').eq(0).find('img').first().addClass('flex-active').attr('aria-pressed', 'true');
                    $current.data('nakhRisehActiveSlide', 0);
                });
            }, 100);
        });

        // Variation swatches are intentionally left to the site's existing WooCommerce/theme swatch implementation.
        // Do not generate a second set of color chips or replace the configured attribute colors.

        // Render the second variation attribute (size) as single-select blocks.
        // The original select remains the source of truth for WooCommerce variation matching.
        function setupSizeBlocks($form) {
            var $rows = $form.find('.variations tr');
            if ($rows.length < 2) return;

            var $sizeSelect = $rows.eq(1).find('select').first();
            if (!$sizeSelect.length) return;

            var $cell = $sizeSelect.closest('td');
            var $blocks = $cell.children('.nakh-riseh-ui-size-options');
            if (!$blocks.length) {
                $blocks = $('<div class="nakh-riseh-ui-size-options" role="group" aria-label="انتخاب سایز"></div>');
                $sizeSelect.after($blocks);
                $sizeSelect.addClass('nakh-riseh-ui-size-select-proxy');
            }

            function renderOptions() {
                var currentValue = $sizeSelect.val() || '';
                $blocks.empty();
                $sizeSelect.find('option').each(function () {
                    var $option = $(this);
                    var value = $option.attr('value');
                    if (!value) return;
                    var $button = $('<button type="button" class="nakh-riseh-ui-size-option"></button>')
                        .text($.trim($option.text()))
                        .attr('data-value', value)
                        .attr('aria-pressed', value === currentValue ? 'true' : 'false');
                    if ($option.is(':disabled') || $option.prop('disabled')) {
                        $button.prop('disabled', true).addClass('is-disabled');
                    }
                    if (value === currentValue) $button.addClass('is-selected');
                    $blocks.append($button);
                });
                $blocks.toggle($blocks.children().length > 0);
            }

            $blocks.off('.nakhRisehSizes').on('click.nakhRisehSizes', '.nakh-riseh-ui-size-option:not(:disabled)', function () {
                var value = String($(this).attr('data-value'));
                if ($sizeSelect.val() === value) return;
                $sizeSelect.val(value).trigger('change');
                renderOptions();
            });

            $sizeSelect.off('change.nakhRisehSizes').on('change.nakhRisehSizes', renderOptions);
            $form.off('woocommerce_update_variation_values.nakhRisehSizes reset_data.nakhRisehSizes found_variation.nakhRisehSizes')
                .on('woocommerce_update_variation_values.nakhRisehSizes reset_data.nakhRisehSizes found_variation.nakhRisehSizes', function () {
                    window.setTimeout(renderOptions, 0);
                });
            renderOptions();
        }

        $productPage.find('form.variations_form').each(function () { setupSizeBlocks($(this)); });

        // Accessible +/- controls wrap the native WooCommerce quantity input without replacing it.
        $productPage.find('form.cart .quantity').each(function () {
            var $quantity = $(this);
            var $input = $quantity.find('input.qty').first();
            if (!$input.length || $quantity.data('nakhRisehQuantityReady')) return;
            $quantity.data('nakhRisehQuantityReady', true).addClass('nakh-riseh-ui-quantity');
            var $minus = $('<button type="button" class="nakh-riseh-ui-quantity-btn" aria-label="کاهش تعداد">−</button>');
            var $plus = $('<button type="button" class="nakh-riseh-ui-quantity-btn" aria-label="افزایش تعداد">+</button>');
            $input.before($minus).after($plus);
            function adjust(delta) {
                var current = parseFloat($input.val()) || 0;
                var min = parseFloat($input.attr('min'));
                var max = parseFloat($input.attr('max'));
                var step = parseFloat($input.attr('step'));
                if (!isFinite(min)) min = 1;
                if (!isFinite(step) || step <= 0) step = 1;
                var next = current + delta * step;
                next = Math.max(min, next);
                if (isFinite(max) && max > 0) next = Math.min(max, next);
                $input.val(next).trigger('change');
            }
            $minus.on('click', function () { adjust(-1); });
            $plus.on('click', function () { adjust(1); });
        });

        $productPage.find('.woocommerce-tabs ul.tabs a').on('click', function () {
            var target = $(this).attr('href');
            if (target && target.charAt(0) === '#') {
                window.setTimeout(function () {
                    var $panel = $(target);
                    if ($panel.length && window.matchMedia('(max-width: 620px)').matches) $panel.attr('tabindex', '-1');
                }, 0);
            }
        });
    });
}(jQuery));
