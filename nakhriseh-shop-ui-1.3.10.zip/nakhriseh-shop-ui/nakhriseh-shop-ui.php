<?php
/**
 * Plugin Name: Nakhriseh Shop UI
 * Description: Independent, scoped WooCommerce shop and product-page redesign for Nakhriseh.
 * Version: 1.3.10
 * Author: Aryana System
 * Text Domain: nakhriseh-shop-ui
 * Requires Plugins: woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Nakhriseh_Shop_UI {
    const VERSION = '1.3.10';

    public function __construct() {
        add_filter( 'body_class', array( $this, 'body_classes' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ), 30 );
        add_action( 'wp', array( $this, 'remove_native_single_sale_flash' ), 20 );
        add_action( 'woocommerce_single_product_summary', array( $this, 'render_product_kicker' ), 4 );
        add_action( 'woocommerce_after_add_to_cart_form', array( $this, 'render_purchase_notes' ), 20 );
        add_filter( 'woocommerce_product_tabs', array( $this, 'rename_product_tabs' ), 20 );
        add_action( 'woocommerce_before_shop_loop_item_title', array( $this, 'render_sale_label' ), 6 );
        add_action( 'woocommerce_product_thumbnails', array( $this, 'render_single_sale_label' ), 20 );
    }

    /** Remove WooCommerce's default single-product sale flash; the plugin renders one replacement. */
    public function remove_native_single_sale_flash() {
        if ( function_exists( 'is_product' ) && is_product() ) {
            remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
        }
    }

    public function body_classes( $classes ) {
        if ( function_exists( 'is_product' ) && is_product() ) {
            $classes[] = 'nakh-riseh-ui-product-page';
        }
        if ( function_exists( 'is_shop' ) && ( is_shop() || is_product_category() || is_product_tag() ) ) {
            $classes[] = 'nakh-riseh-ui-shop-archive';
        }
        if ( function_exists( 'is_cart' ) && is_cart() ) {
            $classes[] = 'nakh-riseh-ui-cart-page';
        }
        return $classes;
    }

    public function enqueue_assets() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        $load_product = function_exists( 'is_product' ) && is_product();
        $load_archive = function_exists( 'is_shop' ) && ( is_shop() || is_product_category() || is_product_tag() );
        $load_cart = function_exists( 'is_cart' ) && is_cart();
        if ( ! $load_product && ! $load_archive && ! $load_cart ) {
            return;
        }

        $base_url = plugin_dir_url( __FILE__ );
        $base_path = plugin_dir_path( __FILE__ );
        $css_file = $base_path . 'assets/css/nakhriseh-shop-ui.css';
        $js_file  = $base_path . 'assets/js/nakhriseh-shop-ui.js';

        wp_enqueue_style(
            'nakhriseh-shop-ui',
            $base_url . 'assets/css/nakhriseh-shop-ui.css',
            array(),
            file_exists( $css_file ) ? (string) filemtime( $css_file ) : self::VERSION
        );
        wp_enqueue_script(
            'nakhriseh-shop-ui',
            $base_url . 'assets/js/nakhriseh-shop-ui.js',
            array( 'jquery', 'wc-single-product', 'wc-add-to-cart-variation' ),
            file_exists( $js_file ) ? (string) filemtime( $js_file ) : self::VERSION,
            true
        );
    }

    public function render_product_kicker() {
        global $product;
        if ( ! $product instanceof WC_Product ) {
            return;
        }
        $categories = wc_get_product_category_list( $product->get_id(), ' / ' );
        echo '<div class="nakh-riseh-ui-product-kicker">';
        echo '<span class="nakh-riseh-ui-kicker-mark" aria-hidden="true"></span>';
        echo '<span>' . wp_kses_post( $categories ? $categories : esc_html__( 'انتخاب نخ‌ریسه', 'nakhriseh-shop-ui' ) ) . '</span>';
        echo '</div>';
    }

    public function render_purchase_notes() {
        if ( ! function_exists( 'is_product' ) || ! is_product() ) {
            return;
        }
        echo '<div class="nakh-riseh-ui-purchase-notes" aria-label="مزیت‌های خرید از نخ‌ریسه">';
        echo '<div class="nakh-riseh-ui-purchase-note"><span class="nakh-riseh-ui-note-icon" aria-hidden="true">♧</span><span><strong>ارسال سریع</strong><small>به سراسر کشور</small></span></div>';
        echo '<div class="nakh-riseh-ui-purchase-note"><span class="nakh-riseh-ui-note-icon" aria-hidden="true">✓</span><span><strong>تضمین کیفیت</strong><small>محصولات اصل</small></span></div>';
        echo '<div class="nakh-riseh-ui-purchase-note"><span class="nakh-riseh-ui-note-icon" aria-hidden="true">☏</span><span><strong>پشتیبانی</strong><small>پاسخگویی سریع</small></span></div>';
        echo '</div>';
    }


    public function rename_product_tabs( $tabs ) {
        if ( isset( $tabs['description'] ) ) {
            $tabs['description']['title'] = 'توضیحات';
        }
        if ( isset( $tabs['additional_information'] ) ) {
            $tabs['additional_information']['title'] = 'مشخصات محصول';
        }
        if ( isset( $tabs['reviews'] ) ) {
            $tabs['reviews']['title'] = 'نظر خریداران';
        }
        return $tabs;
    }

    public function render_sale_label() {
        global $product;
        if ( ! $product instanceof WC_Product || ! $product->is_on_sale() ) {
            return;
        }
        echo '<span class="nakh-riseh-ui-sale-label">پیشنهاد ویژه</span>';
    }

    public function render_single_sale_label() {
        global $product;
        if ( ! function_exists( 'is_product' ) || ! is_product() || ! $product instanceof WC_Product || ! $product->is_on_sale() ) {
            return;
        }
        echo '<span class="nakh-riseh-ui-sale-label nakh-riseh-ui-sale-label--single">پیشنهاد ویژه</span>';
    }
}

add_action( 'plugins_loaded', function() {
    if ( class_exists( 'WooCommerce' ) ) {
        new Nakhriseh_Shop_UI();
    }
} );
